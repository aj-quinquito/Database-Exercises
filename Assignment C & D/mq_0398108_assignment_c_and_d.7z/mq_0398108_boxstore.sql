/*
** Name: Mariah Anjannelle Quinquito
** Assignment: SQL Competency C & D
** Date: '2024-01-24 03:36:00'
** History: 2024-01-24
**          DROP TABLE IF EXISTS
** 			Created a table to hold the CSV data
**          TRUNCATE TABLE
** 			Load data from CSV into the temporary table
** 			SELECT data from the table
**
**/


-- -------------------------------------------------------------------
--
DROP TABLE IF EXISTS people_table;

-- -------------------------------------------------------------------
--
CREATE TABLE people_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255)
);

-- -------------------------------------------------------------------
--
TRUNCATE TABLE people_table;

-- -------------------------------------------------------------------
--
LOAD DATA INFILE 
'C:/Program Files/MariaDB 11.4/data/imports/10000_people_10000.csv'
INTO TABLE people_table
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES (name);


-- -------------------------------------------------------------------
--
SELECT * FROM people_table;
